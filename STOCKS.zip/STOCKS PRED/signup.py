import streamlit as st

def signup():
    st.title("Signup")
    st.write("Create a new account")

    # Unique keys for text input widgets
    username = st.text_input("Username", key="username_input")
    password = st.text_input("Password", type="password", key="password_input")
    confirm_password = st.text_input("Confirm Password", type="password", key="confirm_password_input")

    if st.button("Signup"):
        if password == confirm_password:
            # You can add signup logic here
            st.success("Account created successfully!")
        else:
            st.error("Passwords do not match. Please try again.")
