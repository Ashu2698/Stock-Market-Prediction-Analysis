import streamlit as st
import sqlite3

def login():
    st.title("Login")

    # CSS styling for the login form
    st.markdown(
        """
        <style>
            .login-container {
                max-width: 400px;
                padding: 20px;
                margin: auto;
                background-color: #f9f9f9;
                border-radius: 10px;
                box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            }
            .login-header {
                font-size: 24px;
                margin-bottom: 20px;
                text-align: center;
            }
            .login-input {
                width: 100%;
                padding: 10px;
                margin-bottom: 10px;
                border: 1px solid #ccc;
                border-radius: 5px;
                box-sizing: border-box;
            }
            .login-button {
                width: 100%;
                padding: 10px;
                border: none;
                border-radius: 5px;
                background-color: #4CAF50;
                color: white;
                cursor: pointer;
            }
            .login-button:hover {
                background-color: #45a049;
            }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Login form
    with st.form(key='login-form', clear_on_submit=True):
        st.markdown("<div class='login-container'>", unsafe_allow_html=True)
        st.markdown("<h2 class='login-header'>Login</h2>", unsafe_allow_html=True)
        username = st.text_input("Username", key='username')
        password = st.text_input("Password", type="password", key='password')
        login_button = st.form_submit_button("Login")
        st.markdown("</div>", unsafe_allow_html=True)

        if login_button:
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
            if c.fetchone():
                st.success(f"Logged in as {username}")
                st.session_state.logged_in = True
            else:
                st.error("Invalid credentials")
            conn.close()

if __name__ == "__main__":
    login()
